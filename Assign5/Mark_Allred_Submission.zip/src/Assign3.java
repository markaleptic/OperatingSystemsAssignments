/**
 * @author      Mark Allred, A01647260 <mark.allred@aggiemail.usu.edu>
 */
public class Assign3{
    
    public static void main(String[] args){

        CommandLineInterpreter cli = new CommandLineInterpreter();
        cli.startInterpreter();
        
    }    
}